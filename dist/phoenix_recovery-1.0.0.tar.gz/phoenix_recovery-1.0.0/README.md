# Phoenix Data Recovery Tool

An advanced data recovery tool for recovering files after ransomware attacks or corruption.

## Features

- File integrity verification using SHA-256 hashing
- Backup comparison and recovery
- Dry-run mode for safe testing
- Detailed logging
- Both CLI and GUI interfaces
- Cross-platform support (Windows, macOS, Linux)

## Installation

### From PyPI (Recommended)

```bash
pip install phoenix-recovery
```

### From Source

```bash
git clone https://github.com/yourusername/phoenix-recovery.git
cd phoenix-recovery
pip install -e .
```

## Usage

### Command Line Interface

```bash
# Show help
phoenix --help

# Dry run (simulate recovery)
phoenix -o /path/to/corrupted/files -b /path/to/backup --dry-run

# Actual recovery
phoenix -o /path/to/corrupted/files -b /path/to/backup

# List backup files
phoenix -o /path/to/corrupted/files -b /path/to/backup --list

# Enable debug logging
phoenix -o /path/to/corrupted/files -b /path/to/backup --debug
```

### Graphical Interface

```bash
# Launch GUI
phoenix-gui
```

## Development

### Requirements

- Python 3.7+
- rich (for CLI formatting)
- tkinter (for GUI, usually comes with Python)

### Setting up Development Environment

1. Clone the repository
2. Create a virtual environment:
   ```bash
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```
3. Install development dependencies:
   ```bash
   pip install -e ".[dev]"
   ```

### Running Tests

```bash
python -m pytest tests/
```

## License

MIT License - see LICENSE file for details.

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to the branch
5. Create a Pull Request

## Security

If you discover any security-related issues, please email security@yourdomain.com instead of using the issue tracker.

## Credits

Created by [Your Name] 